import user from "./user.png";
import distributor from "./distributor.svg";
import home from "./home.svg";
import setting from "./setting.svg";
import logout from "./logout.svg";
import appmangement from "./appmanagement.svg";
export { user, distributor, appmangement, home, setting, logout };
