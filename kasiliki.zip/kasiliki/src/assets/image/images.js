import user from "./user.svg";
import distributor from "./distributor.svg";
import home from "./home.svg";
import setting from "./setting.svg";
import logout from "./logout.svg";
export { user, distributor, home, setting, logout };
